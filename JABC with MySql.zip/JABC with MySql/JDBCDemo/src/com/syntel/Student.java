package com.syntel;

import java.io.Serializable;

public class Student implements Serializable{
	int eid,age;
	public int getEid() {
		return eid;
	}
	public Student() {
		super();
	}
	public Student(int eid,  String name,int age) {
		super();
		this.eid = eid;
		this.age = age;
		this.name = name;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	String name;
	public String toString()
	{
		return eid+name+age;
	}

}
