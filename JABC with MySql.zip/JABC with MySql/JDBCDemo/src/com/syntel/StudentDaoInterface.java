package com.syntel;
import java.util.*;
public interface StudentDaoInterface {
	boolean insertStudent(Student tsu);
	boolean deleteStudent(int id);
	Student getStudent(int id);
	boolean updateStudent(int id,String name,int age);
	List<Student> getAllStudent();
	List<Student> getAllStudentBetAge(int min,int max);
	//List<Account> getAllAccountsWithBalanceBetween(double min,double max);
}
