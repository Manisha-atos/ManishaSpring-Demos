package com.syntel;

import java.util.Random;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
public static void main(String[] args) {
	
ApplicationContext context=new ClassPathXmlApplicationContext("beans-jdbc.xml");
	
StudentDaoInterface sd=(StudentDaoInterface)context.getBean("sdao");

Random r=new Random();
/*
System.out.println("Insert 4 accounts \n============================");
System.out.println(sd.insertStudent(new Student(r.nextInt(100),"Manisha",22)));
System.out.println(sd.insertStudent(new Student(r.nextInt(100),"nisha",12)));
System.out.println(sd.insertStudent(new Student(r.nextInt(100),"anisha",20)));
System.out.println(sd.insertStudent(new Student(r.nextInt(100),"isha",25)));


//display all the records	/*
System.out.println("Account Details\n===========================");
for(Student account:sd.getAllStudent())
	System.out.println(account);*/

	


//display all the records	

System.out.println("Student Details\n===========================");
for(Student x:sd.getAllStudentBetAge(20,25))
	System.out.println(x);





}
}