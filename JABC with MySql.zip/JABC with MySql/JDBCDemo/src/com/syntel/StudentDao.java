package com.syntel;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDao implements StudentDaoInterface{
private JdbcTemplate jdbcTemplate;
	
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	@Override
	public boolean insertStudent(Student stu) {
		//jdbcTemplate
		return jdbcTemplate.update("insert into student values(?,?,?)", 
				stu.getEid(), stu.getName(),
				stu.getAge())==1;
	}

	@Override
	public boolean deleteStudent(int id) {
		return 	jdbcTemplate.update("delete from student where id=?",id)==1;
		
	}

	@Override
	public Student getStudent(int id) {
		return jdbcTemplate.queryForObject("select * from student where id=?",Student.class,id);
		
	}

	@Override
	public boolean updateStudent(int id, String name, int age) {
		return jdbcTemplate.update("update Student set age=? where id=?",age,id)==1;
	}

	@Override
	public List<Student> getAllStudent() {
		return jdbcTemplate.query("select * from student", new StudentMapper());
	}
	@Override
	public List<Student> getAllStudentBetAge(int min, int max) {
		return jdbcTemplate.query("select * from student where age between ? and ?", new StudentMapper(), min, max);

	}

}
